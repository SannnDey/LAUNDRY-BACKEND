package com.haylaundry.service.backend.core.enums;

import com.haylaundry.service.backend.jooq.gen.enums.*;

public class EnumConverter {
    public static TipeCucian convertPesananTipeCucianToTipeCucian(com.haylaundry.service.backend.jooq.gen.enums.PesananTipeCucian pesananTipeCucian) {
        switch (pesananTipeCucian) {
            case Super_Express_3_Jam_Komplit:
                return TipeCucian.SUPER_EXPRESS_3_JAM_KOMPLIT;
            case Express_1_Hari:
                return TipeCucian.EXPRESS_1_HARI;
            case Standar_2_Hari:
                return TipeCucian.STANDAR_2_HARI;
            case Reguler_3_Hari:
                return TipeCucian.REGULER_3_HARI;
            default:
                throw new IllegalArgumentException("Unknown TipeCucian: " + pesananTipeCucian);
        }
    }

    public static com.haylaundry.service.backend.jooq.gen.enums.PesananTipeCucian convertTipeCucianToPesananTipeCucian(TipeCucian tipeCucian) {
        switch (tipeCucian) {
            case SUPER_EXPRESS_3_JAM_KOMPLIT:
                return PesananTipeCucian.Super_Express_3_Jam_Komplit;
            case EXPRESS_1_HARI:
                return PesananTipeCucian.Express_1_Hari;
            case STANDAR_2_HARI:
                return PesananTipeCucian.Standar_2_Hari;
            case REGULER_3_HARI:
                return PesananTipeCucian.Reguler_3_Hari;
            default:
                throw new IllegalArgumentException("Unknown TipeCucian: " + tipeCucian);
        }
    }

    public static JenisCucian convertPesananJenisCucianToJenisCucian(com.haylaundry.service.backend.jooq.gen.enums.PesananJenisCucian pesananJenisCucian) {
        switch (pesananJenisCucian) {
            case Komplit:
                return JenisCucian.KOMPLIT;
            case Cuci_Lipat:
                return JenisCucian.CUCI_LIPAT;
            case Setrika:
                return JenisCucian.SETRIKA;
            default:
                throw new IllegalArgumentException("Unknown JenisCucian: " + pesananJenisCucian);
        }
    }

    public static com.haylaundry.service.backend.jooq.gen.enums.PesananJenisCucian convertJenisCucianToPesananJenisCucian(JenisCucian jenisCucian) {
        switch (jenisCucian) {
            case KOMPLIT:
                return PesananJenisCucian.Komplit;
            case CUCI_LIPAT:
                return PesananJenisCucian.Cuci_Lipat;
            case SETRIKA:
                return PesananJenisCucian.Setrika;
            default:
                throw new IllegalArgumentException("Unknown JenisCucian: " + jenisCucian);
        }
    }

    public static PaymentStatus convertPesananStatusBayarToStatusBayar(com.haylaundry.service.backend.jooq.gen.enums.PesananStatusBayar pesananStatusBayar) {
        switch (pesananStatusBayar) {
            case Belum_Lunas:
                return PaymentStatus.BELUM_LUNAS;
            case Lunas:
                return PaymentStatus.LUNAS;
            default:
                throw new IllegalArgumentException("Unknown StatusBayar: " + pesananStatusBayar);
        }
    }

    public static com.haylaundry.service.backend.jooq.gen.enums.PesananStatusBayar convertStatusBayarToPesananStatusBayar(PaymentStatus statusBayar) {
        switch (statusBayar) {
            case BELUM_LUNAS:
                return PesananStatusBayar.Belum_Lunas;
            case LUNAS:
                return PesananStatusBayar.Lunas;
            default:
                throw new IllegalArgumentException("Unknown StatusBayar: " + statusBayar);
        }
    }

    public static StatusOrder convertPesananStatusOrderToStatusOrder(com.haylaundry.service.backend.jooq.gen.enums.PesananStatusOrder pesananStatusOrder) {
        switch (pesananStatusOrder) {
            case Pickup:
                return StatusOrder.PICKUP;
            case Cuci:
                return StatusOrder.CUCI;
            case Selesai:
                return StatusOrder.SELESAI;
            default:
                throw new IllegalArgumentException("Unknown StatusOrder: " + pesananStatusOrder);
        }
    }

    public static com.haylaundry.service.backend.jooq.gen.enums.PesananStatusOrder convertStatusOrderToPesananStatusOrder(StatusOrder statusOrder) {
        switch (statusOrder) {
            case PICKUP:
                return PesananStatusOrder.Pickup;
            case CUCI:
                return PesananStatusOrder.Cuci;
            case SELESAI:
                return PesananStatusOrder.Selesai;
            default:
                throw new IllegalArgumentException("Unknown StatusOrder: " + statusOrder);
        }
    }

    public static PaymentType convertPesananTipePembayaranToTipePembayaran(com.haylaundry.service.backend.jooq.gen.enums.PesananTipePembayaran pesananTipePembayaran) {
        switch (pesananTipePembayaran) {
            case Cash:
                return PaymentType.CASH;
            case QRIS:
                return PaymentType.QRIS;
            default:
                throw new IllegalArgumentException("Unknown TipePembayaran: " + pesananTipePembayaran);
        }
    }

    public static com.haylaundry.service.backend.jooq.gen.enums.PesananTipePembayaran convertTipePembayaranToPesananTipePembayaran(PaymentType tipePembayaran) {
        switch (tipePembayaran) {
            case CASH:
                return PesananTipePembayaran.Cash;
            case QRIS:
                return com.haylaundry.service.backend.jooq.gen.enums.PesananTipePembayaran.QRIS;
            default:
                throw new IllegalArgumentException("Unknown TipePembayaran: " + tipePembayaran);
        }
    }
}
